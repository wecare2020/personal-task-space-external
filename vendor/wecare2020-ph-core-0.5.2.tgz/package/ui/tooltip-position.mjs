export function placeTooltip(anchor, tip, viewport, below = false) {
  const margin=12, gap=8;
  const clamp=(value,min,max)=>Math.max(min,Math.min(value,Math.max(min,max)));
  const above=anchor.top-tip.height-gap, under=anchor.bottom+gap;
  const preferred=below?under:above, alternate=below?above:under;
  const fits=value=>value>=margin&&value+tip.height<=viewport.height-margin;
  return {
    left:clamp(anchor.left+(anchor.width-tip.width)/2,margin,viewport.width-tip.width-margin),
    top:clamp(fits(preferred)?preferred:alternate,margin,viewport.height-tip.height-margin),
  };
}
