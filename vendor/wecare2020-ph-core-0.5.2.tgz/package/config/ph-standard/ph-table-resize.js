(function(root){
 'use strict';
 // Presentation preferences only. This module never reads/writes a data adapter.
 const MIN=80,MAX=1200,STORE='ph-table-column-widths:v1';
 const clamp=value=>Math.round(Math.max(MIN,Math.min(MAX,Number(value)||MIN)));
 const hash=value=>{let h=2166136261;for(const c of value)h=Math.imul(h^c.charCodeAt(0),16777619);return (h>>>0).toString(36);};
 const text=cell=>(cell.querySelector('[data-ph-column]')?.dataset.phColumnLabel||cell.querySelector('.table-column-label')?.textContent||cell.textContent||'').trim();
 function routeContext(location){
  const [path,query='']=String(location.hash||'').split('?'),params=new URLSearchParams(query);
  for(const key of [...params.keys()])if(!['process','version','component','page','view','category'].includes(key))params.delete(key);
  return location.pathname+'|'+path+'|'+params.toString()+'|'+new URLSearchParams(location.search||'').get('demo');
 }
 function readPreferences(storage){try{const data=JSON.parse(storage.getItem(STORE)||'{}');return data&&typeof data==='object'&&!Array.isArray(data)?data:{};}catch{return {};}}
 function writePreferences(storage,key,widths){
  try{const data=readPreferences(storage);delete data[key];data[key]=widths;const keys=Object.keys(data);for(const old of keys.slice(0,Math.max(0,keys.length-120)))delete data[old];storage.setItem(STORE,JSON.stringify(data));return true;}catch{return false;}
 }
 function install(doc,options={}){
  const win=doc.defaultView,states=new WeakMap();let active=null,queued=false,closed=false,moveFrame=0;
  const storage=options.storage||(()=>{try{return win.localStorage;}catch{return null;}})();
  const preferences=readPreferences(storage),lang=()=>doc.documentElement.lang.startsWith('en');
  const label=cell=>lang()?'Resize column '+text(cell):'Đổi độ rộng cột '+text(cell);
  const cells=table=>[...(table.tHead?.rows[0]?.cells||[])];
  const eligible=cell=>cell.colSpan===1&&!!text(cell)&&!cell.querySelector('input[type=checkbox],input[type=radio],.sr-only,.views-sr-only')&&!cell.classList.contains('sheet-corner')&&cell.dataset.resize!=='false';
  const columnKey=(cell,index)=>cell.dataset.columnKey||cell.dataset.column||cell.querySelector('[data-ph-column]')?.dataset.phColumn||cell.querySelector('[data-sim="sort-column"]')?.dataset.id||cell.querySelector('[data-resize-column-key]')?.dataset.resizeColumnKey||text(cell)||String(index);
  function identify(table,heads){
   const owner=table.closest('[data-config-component]')?.dataset.configComponent||table.closest('[data-component]')?.dataset.component||'';
   const title=table.dataset.resizeKey||table.getAttribute('aria-label')||table.closest('[role=region]')?.getAttribute('aria-label')||table.closest('section')?.getAttribute('aria-label')||table.id||table.className||'table';
   return hash(routeContext(win.location)+'|'+owner+'|'+title+'|'+heads.map(columnKey).join('|'));
  }
  function makeGroup(state){
   const {table,heads}=state;let group=[...table.children].find(node=>node.tagName==='COLGROUP');
   if(!group){group=doc.createElement('colgroup');group.dataset.phResizeOwned='true';table.insertBefore(group,table.tHead);}
   while(group.children.length<heads.length)group.append(doc.createElement('col'));
   return [...group.children].slice(0,heads.length);
  }
  function apply(state){
   if(!state.widths)return;const cols=makeGroup(state),sum=state.widths.reduce((a,b)=>a+b,0);
   state.table.dataset.phColumnsSized='true';state.table.style.tableLayout='fixed';state.table.style.width=sum+'px';state.table.style.minWidth=sum+'px';state.table.style.maxWidth='none';
   cols.forEach((col,i)=>{if(col.style.width!==state.widths[i]+'px')col.style.width=state.widths[i]+'px';});
   state.heads.forEach((head,i)=>{if(head.style.width!==state.widths[i]+'px')head.style.width=state.widths[i]+'px';head.querySelector('.ph-column-resize-handle')?.setAttribute('aria-valuenow',state.widths[i]);});
  }
  function restore(state,snapshot){
   state.widths=snapshot.widths;state.userWidths=snapshot.userWidths;
   if(state.widths){apply(state);return;}
   delete state.table.dataset.phColumnsSized;state.table.setAttribute('style',snapshot.tableStyle||'');
   const group=state.table.querySelector('colgroup');
   if(group?.dataset.phResizeOwned)group.remove();else [...group?.children||[]].forEach((col,i)=>col.setAttribute('style',snapshot.colStyles[i]||''));
   state.heads.forEach((head,i)=>head.setAttribute('style',snapshot.headStyles[i]||''));
  }
  function remember(state){
   if(state.table.dataset.phResizeSchema!==undefined&&state.table.closest('.builder-node.is-design')&&state.lastChanged){state.table.dispatchEvent(new win.CustomEvent('ph-column-width-change',{bubbles:true,detail:state.lastChanged}));return;}
   preferences[state.key]={...state.userWidths};writePreferences(storage,state.key,state.userWidths);
  }
  function resize(state,index,width){
   state.widths||=state.heads.map(head=>Math.round(head.getBoundingClientRect().width));
   state.widths[index]=clamp(width);state.lastChanged={key:state.keys[index],width:state.widths[index]};state.userWidths[state.keys[index]]=state.widths[index];apply(state);
  }
  function end(cancel=false){
   if(!active)return;const current=active;active=null;if(moveFrame)win.cancelAnimationFrame(moveFrame);moveFrame=0;
   if(cancel)restore(current.state,current.snapshot);else if(current.changed)remember(current.state);
   current.guide.remove();doc.documentElement.classList.remove('ph-column-resizing');current.handle.classList.remove('is-resizing');
   try{current.handle.releasePointerCapture(current.pointerId);}catch{}
  }
  function begin(event,state,index,handle){
   if(event.button!==0||event.isPrimary===false)return;event.preventDefault();event.stopImmediatePropagation();end(true);
   const snapshot={widths:state.widths?.slice()||null,userWidths:{...state.userWidths},tableStyle:state.table.getAttribute('style'),colStyles:[...state.table.querySelectorAll('colgroup>col')].map(col=>col.getAttribute('style')),headStyles:state.heads.map(head=>head.getAttribute('style'))};
   const guide=doc.createElement('div');guide.className='ph-column-resize-guide';guide.hidden=true;doc.body.append(guide);
   active={state,index,handle,pointerId:event.pointerId,startX:event.clientX,startWidth:state.heads[index].getBoundingClientRect().width,snapshot,guide,changed:false};
   try{handle.setPointerCapture(event.pointerId);}catch{}
  }
  function move(event){
   if(!active||event.pointerId!==active.pointerId)return;const x=event.clientX;
   if(Math.abs(x-active.startX)<3&&!active.changed)return;
   event.preventDefault();if(moveFrame)win.cancelAnimationFrame(moveFrame);
   moveFrame=win.requestAnimationFrame(()=>{moveFrame=0;if(!active)return;const a=active;if(!a.handle.isConnected){end(true);return;}
    a.changed=true;resize(a.state,a.index,a.startWidth+x-a.startX);doc.documentElement.classList.add('ph-column-resizing');a.handle.classList.add('is-resizing');
    const box=a.state.table.getBoundingClientRect(),edge=a.state.heads[a.index].getBoundingClientRect();a.guide.hidden=false;
    Object.assign(a.guide.style,{left:edge.right+'px',top:edge.top+'px',height:Math.max(0,Math.min(box.bottom,win.innerHeight)-edge.top)+'px'});
   });
  }
  function autoFit(state,index){
   let width=MIN;const canvas=doc.createElement('canvas'),context=canvas.getContext('2d');
   for(const row of [...state.table.rows].slice(0,201)){
    const cell=row.cells[index];if(!cell||cell.colSpan>1)continue;
    const style=win.getComputedStyle(cell),content=cell.querySelector('input:not([type=checkbox]),textarea,select')?.value||text(cell);
    if(context)context.font=style.font||'14px Roboto';
    const measured=Math.max(...String(content).slice(0,3000).split('\n').map(line=>context?context.measureText(line).width:line.length*8));
    const inset=cell.querySelector('.step-tree-name,.editable-tree-name')?.style.paddingInlineStart||'0';
    width=Math.max(width,measured+(parseFloat(style.paddingLeft)||0)+(parseFloat(style.paddingRight)||0)+(parseFloat(inset)||0)+34);
   }
   resize(state,index,Math.min(800,width));remember(state);
  }
  function enhance(){
   if(closed)return;if(active&&!active.handle.isConnected)end(true);
   for(const table of doc.querySelectorAll('table')){
    if(table.closest('.ProseMirror,.bn-container,[contenteditable=true],[data-no-column-resize],.sheet-import-table')||!table.getClientRects().length)continue;
    const heads=cells(table);if(!heads.length||heads.some(head=>head.colSpan!==1))continue;
    const key=identify(table,heads);let state=states.get(table);const schemaBase=state?.schemaBase;
    if(!state||state.key!==key||heads.some((head,i)=>state.heads[i]!==head)){
     if(active?.state===state)end(true);
     if(state&&state.key!==key)restore(state,{widths:null,userWidths:{},...state.original});
     state={table,heads,key,keys:heads.map(columnKey),schemaBase:table.dataset.phResizeSchema!==undefined?schemaBase:undefined,widths:null,userWidths:table.dataset.phResizeSchema!==undefined?{}:{...(preferences[key]||{})}};state.original={tableStyle:table.getAttribute('style'),colStyles:[...table.querySelectorAll('colgroup>col')].map(col=>col.getAttribute('style')),headStyles:heads.map(head=>head.getAttribute('style'))};states.set(table,state);
     if(Object.keys(state.userWidths).length){state.widths=heads.map((head,i)=>Number.isFinite(state.userWidths[state.keys[i]])?clamp(state.userWidths[state.keys[i]]):Math.round(head.getBoundingClientRect().width));apply(state);}
    }else apply(state);
    if(table.dataset.phResizeSchema!==undefined&&state.schemaSignature!==table.dataset.phResizeSchema){
     let schema;try{schema=JSON.parse(table.dataset.phResizeSchema);}catch{schema={};}
     state.schemaBase||=Object.fromEntries(heads.map((head,i)=>[state.keys[i],Math.round(head.getBoundingClientRect().width)]));
     state.widths=heads.map((head,i)=>Number.isFinite(schema[state.keys[i]])?clamp(schema[state.keys[i]]):state.schemaBase[state.keys[i]]||Math.round(head.getBoundingClientRect().width));state.schemaSignature=table.dataset.phResizeSchema;apply(state);
    }
    heads.forEach((head,index)=>{
     if(!eligible(head))return;head.classList.add('ph-resizable-header');if(win.getComputedStyle(head).position==='static')head.style.position='relative';
     let handle=head.querySelector('.ph-column-resize-handle');if(handle&&handle.dataset.phResizeOwner!==key){handle.remove();handle=null;}if(handle){handle.setAttribute('aria-label',label(head));return;}
     handle=doc.createElement('span');handle.className='ph-column-resize-handle';handle.dataset.phResizeOwner=key;handle.tabIndex=0;handle.setAttribute('role','separator');handle.setAttribute('aria-orientation','vertical');handle.setAttribute('aria-label',label(head));handle.setAttribute('aria-valuemin',MIN);handle.setAttribute('aria-valuemax',MAX);handle.setAttribute('aria-valuenow',Math.round(head.getBoundingClientRect().width));head.append(handle);
     // Keep resize independent of column menus, row selection and spreadsheet selection.
     for(const type of ['click','mousedown'])handle.addEventListener(type,event=>{event.preventDefault();event.stopImmediatePropagation();},true);
     const binding=()=>{enhance();const current=states.get(table);return {state:current,index:current.heads.indexOf(head),handle:head.querySelector('.ph-column-resize-handle')||handle};};
     handle.addEventListener('pointerdown',event=>{const current=binding();begin(event,current.state,current.index,current.handle);});
     handle.addEventListener('dblclick',event=>{event.preventDefault();event.stopImmediatePropagation();const current=binding();autoFit(current.state,current.index);});
     handle.addEventListener('keydown',event=>{
      if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();event.stopPropagation();
      const current=binding();state=current.state;index=current.index;const width=state.widths?.[index]||head.getBoundingClientRect().width,step=event.shiftKey?40:16;
      resize(state,index,event.key==='Home'?MIN:event.key==='End'?MAX:width+(event.key==='ArrowRight'?step:-step));remember(state);
     });
    });
   }
  }
  const schedule=()=>{if(queued||closed)return;queued=true;win.requestAnimationFrame(()=>{queued=false;enhance();});};
  const observer=new win.MutationObserver(records=>{if(records.some(record=>record.type==='attributes'||[...record.addedNodes,...record.removedNodes].some(node=>node.nodeType===1&&!node.classList?.contains('ph-column-resize-guide'))))schedule();});
  const keydown=event=>{if(active&&event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();end(true);}};
  const pointerup=event=>{if(active&&event.pointerId===active.pointerId){if(moveFrame){win.cancelAnimationFrame(moveFrame);moveFrame=0;if(Math.abs(event.clientX-active.startX)>=3){active.changed=true;resize(active.state,active.index,active.startWidth+event.clientX-active.startX);}}end();}};
  const cancel=()=>end(true);
  doc.addEventListener('pointermove',move,{capture:true,passive:false});doc.addEventListener('pointerup',pointerup,true);doc.addEventListener('pointercancel',cancel,true);doc.addEventListener('keydown',keydown,true);win.addEventListener('blur',cancel);win.addEventListener('hashchange',schedule);win.addEventListener('resize',schedule);
  observer.observe(doc.body,{childList:true,subtree:true,attributes:true,attributeFilter:['data-ph-resize-schema']});schedule();
  return {enhance,destroy(){closed=true;end(true);observer.disconnect();doc.removeEventListener('pointermove',move,true);doc.removeEventListener('pointerup',pointerup,true);doc.removeEventListener('pointercancel',cancel,true);doc.removeEventListener('keydown',keydown,true);win.removeEventListener('blur',cancel);win.removeEventListener('hashchange',schedule);win.removeEventListener('resize',schedule);}};
 }
 const api={clamp,hash,routeContext,readPreferences,writePreferences,install};
 if(typeof module!=='undefined'&&module.exports)module.exports=api;
 if(root.document&&!root.PHTableColumnResize){root.PHTableColumnResize=api;if(root.document.readyState==='loading')root.document.addEventListener('DOMContentLoaded',()=>{api.instance=install(root.document);},{once:true});else api.instance=install(root.document);}
})(typeof window!=='undefined'?window:globalThis);
