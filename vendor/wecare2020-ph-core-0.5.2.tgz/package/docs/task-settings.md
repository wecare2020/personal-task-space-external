# Shared Task Setting

Core owns the reusable Task Setting model, categories, validation, fields,
Type Designer and styles. There are no fetch calls, URLs, storage keys,
server sessions or save operations in this module.

```tsx
import {DEFAULT_TASK_PREFERENCES, TASK_SETTING_DEFINITIONS,
  validPreferences, taskTypeLayout} from '@wecare2020/ph-core/tasks';
import {TaskSettingsFields} from '@wecare2020/ph-core/tasks/react';
import '@wecare2020/ph-core/tasks/styles.css';

<TaskSettingsFields item="types" draft={draft} disabled={busy}
  onChange={(key, value) => setDraft(previous => ({...previous, [key]:value}))}
  relatedDataActions={<AppOwnedBackupActions />} />
```

The app owns draft state, validation before Save, persistence, revision/CAS,
conflict handling and Cancel. Preview uses synthetic local values only; it
does not call onChange for sample input. Attribute IDs and data kinds are
stable. Hide/Restore retains definitions; enforce keepsTaskSchema and
keepsFormDefinitions on the server, not only in the UI.

taskSchema is optional for legacy preferences. parsePreferences preserves the
revision and derives missing defaults without writing. taskTypeLayout selects
the effective per-type fields. Preserve hidden/other-type task values through
validateCustomTaskFields, and apply validateTypeForm only on explicit form saves.

Task Settings exposes eight categories, including Group, Task types,
Task type attribute and Task type x Attribute. Navigation derives from
TASK_SETTING_DEFINITIONS; do not copy that catalogue into consuming apps.

Property / Preview / Edit UI share one settings draft. Undo/Redo is local to
the mounted editor; external Cancel/reset clears obsolete editor history.
Keyboard order controls and the section selector are available without dragging.
The mobile type selector replaces the rail at narrow viewport widths.

Related-data export actions and their security explanations are supplied by
the host through relatedDataActions (or FormLayoutSettings.footer); Core cannot
assume a database, endpoint or backup policy. SelectControl can be injected.

Release flow: change Core, run npm run check, release a new version, update the
pinned dependency in consuming apps, test and deploy each app. Existing deployed
apps do not silently download unreviewed latest code. Personal D1 and the UI
Design System device-local demo remain separate data sources.
