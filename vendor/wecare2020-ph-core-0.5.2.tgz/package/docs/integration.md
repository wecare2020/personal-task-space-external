# Connect PH applications to Core

Use exact package versions and commit the app lockfile. Avoid loading mutable
`main` or runtime CDN scripts into production. Existing apps can adopt individual
entry points gradually while preserving their own UI state and persistence.

## UI Design System

1. Add the versioned package and import `tokens.css` before app overrides.
2. Replace local token definitions with `phTokens` / `--ph-*` variables.
3. Replace matching primitives with `/ui`; keep showcase catalog/configuration local.
4. Adopt `/app` and `/patterns` on a review branch. Check existing examples, keyboard
   behavior, translations and responsive layouts before publishing.

## Process Simulation

1. Add `/config`, `/types`, `/utils` to the existing frontend build.
2. Keep worker auth, workbook identity and version ownership checks in the app.
3. Inject its authenticated API into `createHttpClient`; use revision checks in
   the real adapter. Never substitute a memory adapter for production persistence.
4. React islands can opt into `/ui` and `/patterns` independently of the vanilla shell.
5. The existing compatible shell bridge is provided as `/shell-bridge.js`; confirm
   child/parent handshake and duplicate-branding behavior before replacing it.

## Template App

1. Add `/app`, `/ui`, `/patterns`, `/data` and shared CSS.
2. Keep blueprint schema, routes, connectors, auth server and storage implementation
   in the template/app. Pass explicit labels and app configuration into Core.
3. New generated apps retain this package dependency rather than copying Core files.
4. Preserve local edits, tombstones, rich content and sync defaults when switching
   to shared merge helpers. Test against real adapter semantics first.

## Access and delivery

GitHub Packages is private by default. Authorize each consumer repository to read
the package, or configure its existing deployment secret with `read:packages`.
Never paste credentials into source, config JSON, documentation or browser URLs.
Registry install instructions: https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-npm-registry

Run `npm run check` in Core. In each app, run its current build and relevant
interaction/persistence checks, then publish that app separately. Creating or
releasing Core does not change the running application.

## Release checklist

1. Update `package.json` version, `config/index.ts#CORE_VERSION`, changelog and examples.
2. Run `npm run check` and review packed files.
3. Push the commit and a matching `vX.Y.Z` tag.
4. Confirm Release Core succeeded and registry/tarball are available.
5. Upgrade consumers through a reviewed dependency change with build/test evidence.
