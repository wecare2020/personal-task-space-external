# Architecture

PH Core is a versioned library. It has no database, accounts, production secrets or
deployment of its own. Each consuming app retains its hosting and domain logic.

Dependency direction: `types → utils/config → data → ui → layouts/patterns`.
Auth and builder folders expose extension contracts; implementations remain in apps.
Framework-neutral entry points must never transitively import React or browser globals.

UI Design System is the canonical implementation source. Version 0.2.0 moves its
approved primitives, tooltip, pure helpers and live CSS into compatibility exports,
then the website imports those exports through its original local module paths.
Language, catalogue and persistence context remain injected by the app. Portable
PH CSS and live website CSS retain separate cascade contracts. Process's current
portable CSS snapshot is explicitly exported as `/ui/process-compat.css` to retain
its existing geometry while the default canonical CSS follows UI Design System.

The initial release uses one package with directory entry points. This preserves
the proposed file directory, keeps compatibility changes atomic and works across
independent app repositories. The four logical surfaces are UI, App, Data, Utils;
`/app` aliases `layouts/`. Internal workspace specifiers are not consumer dependencies.

UI Design System becomes the showroom/reference consumer of Core components and
tokens. Process Simulation consumes contracts, config, safe data helpers and React
components only inside its islands. Template App imports the same package in its
starter shell. Domain models, sheet identifiers, worker persistence and app routes
remain in their respective applications.

## Public API rules

- Only `package.json#exports` defines supported imports; no `dist/` deep imports.
- CSS is opt-in and scoped with `ph-` classes and `--ph-` variables; no global reset.
- Tokens are checked in as JSON and generated into CSS and typed values.
- Existing PH component configuration wins over ad hoc substitutions.
- Revision guards protect writes. Merge utilities preserve edited/deleted local rows.
- A memory adapter is for examples/tests; it does not claim server persistence.
- Client permission helpers aid display; the server must enforce authorization.

## Deferred capabilities

Visual form/view/page builders, authentication/session servers, workflow execution,
Dataverse/Sheets connectors, repo/Vercel provisioning and BlockNote integration
remain app-specific until their common contracts and behavior are proven.
