# Source provenance

Inventory and reference verification date: 15 October 2026, Asia/Bangkok.

This document records the existing PH sources used to establish the Core boundaries. Source paths are repository-relative; no workstation paths, account secrets, production record payloads or credentials are included.

## Architecture direction

The user supplied the [shared architecture conversation](https://chatgpt.com/share/6ad0622b-6e14-83ec-b68c-977204a57b44) and requested a separate GitHub Core Library with UI Design System, Process Simulation and the Template application referencing it. Core keeps the directory-based boundaries documented in [consumer-map.md](./consumer-map.md).

## Source applications inspected

| Source | Reference | Local source snapshot observed | Main files inspected |
| --- | --- | --- | --- |
| PH UI Library / UI Design System | [Live library and Config](https://ph-ui-library.khoitran.chatgpt.site/#config) | Checkout HEAD `8987bc77f72059c3ec68c648f494f3b4573315ff` | `package.json`, `public/ph-tokens.json`, `public/ph-design-system.css`, `public/ph-shell-bridge.js`, `public/ph-table-resize.js`, `src/ui.jsx`, `src/Select.jsx`, `src/locale-format.mjs`, `src/table-column-model.mjs`, `src/property-model.mjs`, `src/richtext/blocknote-format-options.ts`, `src/TableStepPane.jsx` |
| PH Process Simulation | [Process Simulation](https://ph-process-simulation.khoitran.chatgpt.site/) | Checkout HEAD `0c1bc18fefa2a961887ac2df2f932e0f1cd405b6` | `package.json`, `AGENTS.md`, `public/component-schema.js`, `public/app-display-model.js`, `public/ph-shell-bridge.js`, `public/ph-table-resize.js`, `src/simulation-definition.mjs`, `src/simulation-reconcile.mjs`, `src/global-settings.mjs`, `ui/process-editor/format-options.mjs` |
| PH Runtime Blueprint / Template | [Source repository](https://github.com/wecare2020/ph-runtime-blueprint), [deployed application](https://ph-runtime-blueprint.vercel.app/) | Checkout HEAD `d62f4890ecd4a8ccac1119ca8914e519da01d663` | `package.json`, `AGENTS.md`, `types.ts`, `runtime.ts`, `Select.tsx`, `property-topics.ts`, `areas.ts`, `connector-model.ts`, `server-sync-merge.ts` |

Checkout HEAD values identify the locally inspected source ancestry. They do not assert that every inspected file was committed at that HEAD or that the live application serves exactly that commit. Only the UI reference assets below received live HTTP verification for this inventory.

## Current PH design reference verified live

Read-only HTTP requests returned status 200 for:

- [PH tokens](https://ph-ui-library.khoitran.chatgpt.site/ph-tokens.json), export version `0.4.0`.
- [Design identity](https://ph-ui-library.khoitran.chatgpt.site/design-identity.json), version `0.4.0`.
- [Design-system CSS](https://ph-ui-library.khoitran.chatgpt.site/ph-design-system.css).

The parsed live tokens matched the inspected local `public/ph-tokens.json` data. The local token file SHA-256 was `08C783B11204BBAC63A50D0D361FD64A05BD82663AD57863F60C1789018E7035`.

Current primary action values are background `#FFFFFF`, foreground `#6E5840`, border `#DDD8D1` and hover background `#F8F9FA`. Live CSS `.ph-btn-primary` uses these token variables. The reference uses field label `#565E65`, selected background `#F3F4F5`, form section title 16px Roboto 600, and the documented neutral form-section shadow. Earlier descriptions of solid walnut primary buttons are superseded by these current reference exports.

The `#config` fragment is client-side application state; this inventory verified its public design assets and inspected local configuration source. It did not perform a live browser interaction audit of every Config control.

## Reuse evidence and coupling

- UI Library and Process Simulation `public/ph-shell-bridge.js` were byte-identical: SHA-256 `E34305A6D8A00E469180493496D023E9A5BC045B773504FAD9CF41FE42883522`. The bridge uses protocol `ph-shell-v1`, checks parent identity and origin, and hides duplicate child chrome only after a trusted handshake. Its existing default shell origin is application-specific and should become explicit consumer configuration during extraction.
- The three `ph-table-resize.js` copies had different hashes. They include application selectors, schema-width events and persistence behavior; treating them as one interchangeable implementation would conceal behavioral differences.
- The applications share React 19.2, Phosphor 2.1.10 and BlockNote 0.55.0 at the inspected snapshots. Process also uses a vanilla shell/worker and esbuild; UI Library is JSX/Vite and Template is TSX/Vite. Framework-neutral modules therefore require a separate import path from React primitives.
- UI Library `src/ui.jsx` combines reusable controls with showcase-only CatalogContext and approved-guidance behavior. `src/Select.jsx` depends on the app Language provider. Extract behavior with explicit labels, translation and icon dependencies rather than moving the whole source module unchanged.
- Template `runtime.ts` validates Template-specific `/settings` and `/tasks` routes and imports process/presentation/connector validators. `connector-model.ts` fixes the Process Simulation public catalog URL. Portable Core validation must not silently impose these application policies on every consumer.
- Template `types.ts` contains useful DataAdapter/AuthAdapter/StudioAdapter contracts, but Definition is coupled to process configuration. Process has a different record envelope and capitalized field types. A schema bridge is required before the applications can share full renderers.
- Template `server-sync-merge.ts` uses Node crypto and server settings document types. It is a server extraction candidate, not a browser-safe module. Preserve its non-destructive merge semantics, local edits/deletions, explicit sync options and application-owned transaction/revision checks when adopting it.

## Implementation status boundary

This source inventory informed the initial Core package. Only symbols present in Core exports and covered by its checks are implemented. The extraction map lists both current foundations and future candidates. Existing production applications were not migrated as part of preparing these documents; no production data, generated company catalogs, sessions or secrets were imported.
