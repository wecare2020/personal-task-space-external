# PH BlockNote editor

Optional React-only entry: `@wecare2020/ph-core/ui/richtext`. Install matching
BlockNote 0.55.x peers only in apps that use rich text:

```sh
npm install --save-exact @blocknote/core@0.55.0 @blocknote/react@0.55.0 @blocknote/ariakit@0.55.0
```

```tsx
import {usePhBlockNote,PhBlockNoteView} from '@wecare2020/ph-core/ui/richtext';
import '@blocknote/ariakit/style.css';
import '@wecare2020/ph-core/ui/richtext/styles.css';

function Notes({blocks,onChange,uploadFile}) {
  const editor=usePhBlockNote({initialContent:blocks,uploadFile});
  return <PhBlockNoteView editor={editor} onChange={()=>onChange(editor.document)}/>;
}
```

Core owns the native schema, slash dictionary, To-do discovery, placeholders,
native link rendering, six-dot Turn into extension, video provider renderer and
quiet UI styling. It uses the supported library APIs and components; CSS only
changes presentation where Ariakit's default stylesheet hard-codes black or
forced scrollbars. The root class is propagated by BlockNote to portalled controls.
Menus retain native vertical scrolling; narrow toolbars remain touch-scrollable.

The app owns canonical serialization/validation, legacy HTML conversion,
snapshot/draft lifecycle, revision/CAS writes, recovery, authorization and uploads.
Pass an app-authorized `uploadFile`; Core contains no app routes, task IDs, API
credentials, storage adapters or production records.

The Personal Task Space consumer retains its existing validated native document
envelope and import adapters. Removing Customer 1 does not delete stored notes
or rewrite the database in a batch. This release does not automatically upgrade
Process Simulation, Team, Alice or the UI Library's own editor.

UI Design System and Process Simulation now consume the same Core entry through
their existing facades. Non-React hosts use `createPhBlockNote`, then mount
`PhBlockNoteView`. Pass `domAttributes` for the app's accessible name. Process
uses `preserveLegacyCode: true` to retain existing code documents; the shared
native slash menu still excludes new code insertion. Read-only views disable
editing controllers. Compact fields may set `--ph-richtext-min-height`,
`--ph-richtext-font-family`, `--ph-richtext-font-size`, `--ph-richtext-line-height`,
`--ph-richtext-padding` and `--ph-richtext-mobile-padding` without forking styles.

Future editor changes are released in Core, then consumers update their pinned
release and rebuild/deploy. They never load mutable runtime source from another app.

Other Core imports never load BlockNote. `/ui/richtext/format-options` contains
pure safe conversion helpers without loading the editor.
