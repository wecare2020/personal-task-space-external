# Production reference ownership

Each shared element has one original production owner. Implement and verify a change there first, promote the reviewed implementation into a versioned Core release, then update inherited consumers explicitly. A consumer update must preserve its existing data, routes, auth, drafts and Save/Cancel behavior.

| Surface | Original owner | Core delivery | Consumer adoption |
| --- | --- | --- | --- |
| PH primitives, tokens, typography, tooltip, public design kit | UI Design System | `ui/canonical/*`, `config/ph-standard/*` snapshots | Original UI keeps its implementation and public exports; children use the appropriate pinned export |
| Native rich text/editor behavior | Personal Task | Optional `ui/richtext` entry | Personal Task remains unchanged; adoption by other hosts is explicit and separately tested |
| Embedded PH host bridge | PH host shell | `shell-bridge.js` | UI Design System and Process materialize the exact installed release |
| Process shell and runtime presentation | Process Simulation, following UI Design System | `ui/process-compat.css` plus `ui/process-runtime.css` | Process materializes both at their existing paths and in their existing order |
| Common Template shell, forms, property/preview/report and mobile presentation | Template production compatibility with UI Design System | `ui/template-*.css` | Eleven existing local CSS paths import the installed release; built CSS must remain equivalent |
| Process settings/project presentation in Template | Process pattern with Template production compatibility | `ui/template-process-settings.css`, `ui/template-project-overview.css` | Existing Template markup and interactions remain app-owned |
| Table resizing | PH UI table pattern; Process/Template compatibility variant | `ui/canonical/table-resize.*` and `table-resize.*` | UI retains its reference variant; Process/Template inherit their existing shared variant |

Compatibility exports intentionally retain the consumer's current production cascade and geometry. They are not permission to overwrite a reference app or silently upgrade installed catalog assets. Future owner changes must include an explicit consumer review and release update. Runtime persistence, schemas, workbook identifiers, sessions, credentials and app business components stay outside Core.

## Task Setting shared module

Task Setting is deliberately Core-owned from 0.5.0 onward. Personal Task Space
and UI Design System import /tasks and /tasks/react rather than keeping separate
copies. Their auth, routes, records, settings storage and draft transactions remain
app-owned. This extraction does not change the reference ownership of other
production editor or application features.
