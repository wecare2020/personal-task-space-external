# Shared UI Builder

`@wecare2020/ph-core/builders/react` owns the canonical BuilderInspector,
BuilderPropertyTabs and BuilderToolbar used by PH UI Library and Runtime.
Import `@wecare2020/ph-core/builders/styles.css` after app compatibility styles.
The implementation promotes the UI Builder v243 inspector anatomy: compact
context header, persistent tabs, one scrollable field surface and full-width
single-column fields. A 300px inspector must never inherit a two-column record form.

Supply translated labels and app-owned field content. Keep panels mounted with
`hidden` and preserve each app's validity reveal, undo, Save/Cancel and dirty guard.
Collapsing or changing a topic does not publish or discard edits. Runtime retains
its authenticated settings adapter; the UI Library retains local design sessions.
Schema, actual records, catalogs, routes, auth and persistence do not belong in Core.

The framework-neutral `/builders` entry remains React-free. React is explicit
through `/builders/react`. Existing builder schema validation is unchanged.
Consumer adoption is pinned to the same release tarball and SHA256; no mutable CDN.
