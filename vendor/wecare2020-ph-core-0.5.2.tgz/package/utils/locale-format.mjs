export const localeFor = language => language === 'en' ? 'en-US' : 'vi-VN';
export function formatDate(value, language = 'vi') {
  if (!value) return '—';
  const date = new Date(`${value}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) return '—';
  return new Intl.DateTimeFormat(localeFor(language), {day:'2-digit',month:'2-digit',year:'numeric',timeZone:'UTC'}).format(date);
}
export const formatNumber = (value, language = 'vi') => new Intl.NumberFormat(localeFor(language)).format(Number(value || 0));
export const formatMoney = (value, language = 'vi') => new Intl.NumberFormat(localeFor(language), {style:'currency',currency:'VND',maximumFractionDigits:0}).format(Number(value || 0));
export function resolveShowcaseView(width, desktopView, tabletView) {
  if (width <= 0) return desktopView;
  if (width < 680) return tabletView === 'card' ? 'card' : 'list';
  return desktopView;
}
