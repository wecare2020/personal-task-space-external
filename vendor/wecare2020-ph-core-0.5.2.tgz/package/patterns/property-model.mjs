// Universal property vocabulary; storage keys and business schemas stay unchanged.
export const PROPERTY_TOPICS=[['general','General'],['design','Design'],['behaviour','Behaviour']];
export const PROPERTY_SECTIONS={general:['Identity','Data','Default'],design:['Content','Layout','Appearance'],behaviour:['Actions','Rules','State & Feedback']};
const fieldsBySection={
 Identity:['name','label','description','mode','type','module','catalogGroup','route','icon'],
 Data:['table','source','binding','context','variables','parameters','measure','workshop'],
 Default:['view','form','defaultView','defaultForm','sort','sortDirection','group','filterStatus','pageSize','initialState'],
 Content:['showQuantity','showTitle','related','text','series'],
 Layout:['layout','columns','width','height','spacing','position','responsive'],
 Appearance:['density','format','variant','color','theme'],
 Actions:['showActions','showSearch','showSelection','rowNumbers','action','command'],
 Rules:['enabled','required','readOnly','visible','inNavigation','permissions'],
 'State & Feedback':['emptyMessage']
};
export function propertySections(fields,kind){
 const assigned=new Set();
 const defaultLayout=['view','page'].includes(kind);
 const result=Object.entries(PROPERTY_SECTIONS).flatMap(([topic,titles])=>titles.map(title=>({topic,title,keys:[...(fieldsBySection[title]||[]),...(title==='Default'&&defaultLayout?['layout']:[])].filter(key=>!(title==='Layout'&&defaultLayout&&key==='layout')&&fields.some(field=>field.key===key)&&(assigned.add(key),true))})));
 // Unclassified supported inputs remain accessible rather than silently disappearing.
 const remaining=fields.filter(field=>!assigned.has(field.key)&&!['visualFields','visualSections'].includes(field.key)).map(field=>field.key);
 result.find(section=>section.title==='Identity').keys.push(...remaining);
 return result.filter(section=>section.keys.length);
}
