export const columnValue=(row,key)=>String(row[key]??'');
export const matchesValueFilter=(value,filter)=>filter==null||filter==='all'||(Array.isArray(filter)?filter.map(String).includes(String(value??'')):String(value??'')===String(filter));
export const valueOptions=(values=[],filter='all')=>[...new Set([...values,...(Array.isArray(filter)?filter:filter==null||filter==='all'?[]:[filter])].filter(value=>value!=null).map(String))];
export const filterSelections=(filter,options)=>filter==null||filter==='all'?options:Array.isArray(filter)?filter.map(String):[String(filter)];
export function matchesColumnFilters(row,filters={},value=columnValue){return Object.entries(filters).every(([key,filter])=>matchesValueFilter(value(row,key),filter));}
export function projectColumnTree(nodes,view,value=columnValue){
 const result=nodes.flatMap(node=>{
  if(node.record)return matchesColumnFilters(node.record,view.filters,value)?[node]:[];
  const children=projectColumnTree(node.children||[],view,value);
  return children.length?[{...node,children,count:children.reduce((sum,child)=>sum+(child.record?1:child.count),0)}]:[];
 });
 if(view.sort?.key)result.sort((a,b)=>String(a.record?value(a.record,view.sort.key):a.title||'').localeCompare(String(b.record?value(b.record,view.sort.key):b.title||''),'vi',{numeric:true})*view.sort.direction);
 return result;
}
export function columnState(key,view={}){return {filtered:view.filters?.[key]!=null&&view.filters[key]!=='all',sorted:view.sort?.key===key&&!(view.sort?.key===view.defaultSort?.key&&view.sort?.direction===view.defaultSort?.direction),grouped:view.groupFields?.includes(key)||false};}
