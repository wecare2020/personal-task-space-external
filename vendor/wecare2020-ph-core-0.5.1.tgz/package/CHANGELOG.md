# Changelog

## 0.5.1

- Merge the Task Setting release with the concurrent 0.4.2 compatibility release.
- Preserve all existing editor, Process and Template exports.

## 0.5.0

- Promote Task Setting categories, type/group/attribute contracts, non-destructive
  validation and Type Designer into optional `/tasks`, `/tasks/react` entries.
- Share settings fields, preview, property inspector, section/field ordering,
  Undo/Redo and responsive styles. Related-data actions are an injected slot.
- Personal Task Space and UI Design System consume the same pinned package.
  Auth, D1, revisions, backups and production records remain app-owned.

## 0.4.2

- Promote unchanged Process runtime styling and eleven Template common presentation layers as explicit compatibility exports.
- Define production reference ownership: UI Design System and Personal Task editor retain their original implementations; children consume reviewed Core releases.
- Preserve all 0.4.1 builder and optional editor exports.


## 0.4.1

- Add a shared imperative editor factory and accessible DOM attributes for non-hook hosts.
- Preserve legacy code blocks on explicit opt-in, without exposing new code insertion.
- Centralize read-only controller behavior and native slash filtering in the shared view.
- Expose layout-only CSS variables so compact PH fields retain their geometry.
- UI Design System and Process Simulation adopt the shared editor; app codecs,
  uploads, drafts and save transactions remain isolated.

## 0.4.0

- Promote the Personal Task Space BlockNote editor UI into optional `/ui/richtext`:
  native schema, slash discovery, safe Turn into menu, allowlisted video renderer,
  quiet empty blocks, links, subtle handles and responsive styling.
- Grey control text/icons and completed checkboxes; muted done text/strike.
  Remove forced scrollbar chrome only on floating toolbars.
- Keep data codecs, legacy import, uploads, authorization, autosave and recovery
  app-owned. Framework-neutral imports do not load React or BlockNote.

## 0.3.0

- Promote UI Builder inspector, keyboard property tabs and toolbar into explicit
  shared React exports. Preserve the framework-neutral builders entry.
- Add canonical single-column inspector styles with fixed tabs and one field
  scroll surface, adapted from the PH UI Builder reference.

## 0.2.0 — 2026-10-15

UI Design System v243 is the canonical source for compatibility primitives, tooltip,
locale/property/table helpers and live styles. Added exact portable PH assets/fonts,
separate resize variants, source provenance and pinned consumer integration surfaces.
Existing application renderers, data/session/workflow boundaries remain app-owned.

## 0.1.0 — 2026-10-15

Initial PH Core Library with directory-based entry points, PH tokens, React UI and
layout primitives, reusable record patterns, framework-neutral data adapters,
validation, safe merge utilities, typed auth/builder extension contracts, examples,
package verification and GitHub Actions.
