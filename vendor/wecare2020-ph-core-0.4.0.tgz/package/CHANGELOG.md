# Changelog

## 0.4.0

- Promote the Personal Task Space BlockNote editor UI into optional `/ui/richtext`:
  native schema, slash discovery, safe Turn into menu, allowlisted video renderer,
  quiet empty blocks, links, subtle handles and responsive styling.
- Grey control text/icons and completed checkboxes; muted done text/strike.
  Remove forced scrollbar chrome only on floating toolbars.
- Keep data codecs, legacy import, uploads, authorization, autosave and recovery
  app-owned. Framework-neutral imports do not load React or BlockNote.

## 0.3.0

- Promote UI Builder inspector, keyboard property tabs and toolbar into explicit
  shared React exports. Preserve the framework-neutral builders entry.
- Add canonical single-column inspector styles with fixed tabs and one field
  scroll surface, adapted from the PH UI Builder reference.

## 0.2.0 — 2026-10-15

UI Design System v243 is the canonical source for compatibility primitives, tooltip,
locale/property/table helpers and live styles. Added exact portable PH assets/fonts,
separate resize variants, source provenance and pinned consumer integration surfaces.
Existing application renderers, data/session/workflow boundaries remain app-owned.

## 0.1.0 — 2026-10-15

Initial PH Core Library with directory-based entry points, PH tokens, React UI and
layout primitives, reusable record patterns, framework-neutral data adapters,
validation, safe merge utilities, typed auth/builder extension contracts, examples,
package verification and GitHub Actions.
