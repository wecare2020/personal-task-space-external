# PH Core Library

Rich text editor: optional [BlockNote entry](docs/richtext.md) at
`@wecare2020/ph-core/ui/richtext`; install BlockNote peers only in editor consumers.

Code dùng chung cho các app PH. Mỗi app giữ repo, dữ liệu, auth server và nghiệp vụ
riêng; import Core bằng dependency có version. Repo này dùng cấu trúc thư mục đúng
theo [định hướng PH Core](https://chatgpt.com/share/6ad0622b-6e14-83ec-b68c-977204a57b44).

## Cấu trúc

```text
ph-core/
├── ui/          React primitives, fields, table, feedback
├── layouts/     AppShell, Sidebar, CommandBar, SplitView, shell bridge
├── patterns/    FormSection, RecordPanel với View/Edit và dirty guard
├── builders/    Schema contracts và UI Builder inspector/toolbar dùng chung
├── data/        DataAdapter, HTTP client, memory adapter, validation, safe merge
├── auth/        Auth/permission contracts để app inject implementation
├── utils/       Formatting và validation dùng chung
├── config/      PH tokens, CSS variables, app defaults
├── types/       Shared TypeScript contracts
├── docs/        Architecture, consumers, versioning, integration
├── examples/    UI Design System, Process Simulation, Template App consumers
└── scripts/     Token generation và kiểm tra package độc lập
```

## Cài đặt

Yêu cầu Node >=22.12; dùng Node 24 trong CI. Gói private trên GitHub Packages:

```ini
# .npmrc của app; token lấy từ secret environment, không commit token thật.
@wecare2020:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

```sh
npm install --save-exact @wecare2020/ph-core@0.3.0
```

GitHub Packages cần quyền đọc package. Repo consumer cần được cấp quyền package
hoặc dùng token hiện có với `read:packages` trong CI/Vercel. Xem
[GitHub Packages documentation](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-npm-registry).
Có thể cài trực tiếp file `.tgz` từ GitHub Release hoặc bản build nội bộ đã kiểm tra.
Đường cài registry chỉ dùng được sau khi workflow Release Core publish thành công.

## Import trong app React

```tsx
import { AppShell, Sidebar, CommandBar } from '@wecare2020/ph-core/app';
import { Button, TextField, DataTable } from '@wecare2020/ph-core/ui';
import { FormSection, RecordPanel } from '@wecare2020/ph-core/patterns';
import { createMemoryAdapter } from '@wecare2020/ph-core/data';
import '@wecare2020/ph-core/styles.css';
```

React và ReactDOM là peer dependencies của các entry UI; app React cần tự cài.
Root, `/data`, `/utils`, `/config`, `/auth`, `/builders`, `/types` không import React.

## Import trong Process Simulation JavaScript

```js
import { phTokens, defineAppConfig } from '@wecare2020/ph-core/config';
import { createHttpClient, mergeRecords } from '@wecare2020/ph-core/data';
import { formatNumber } from '@wecare2020/ph-core/utils';
import '@wecare2020/ph-core/tokens.css';
```

Các React islands có thể dùng thêm `/ui` và `/patterns`. Process/version/workbook,
permission server, schema thực tế và guarded save vẫn do app quản lý.

## Phát triển và kiểm tra

```sh
npm ci
npm run check
npm run dev
```

`check` build TypeScript, kiểm tra consumer types, chạy tests, build ba ví dụ,
đóng gói tarball và cài vào consumer độc lập không có React. Tarball ở `artifacts/`.

## Version và cập nhật app

Một package `@wecare2020/ph-core` với entry points `/ui`, `/app`, `/data`, `/utils`
và các thư mục còn lại giữ cùng một version. Cách này giữ nguyên file directory,
tránh lệch version giữa UI và contracts trong bản đầu. Có thể tách package vật lý
khi có nhu cầu release độc lập, mà vẫn giữ API facade ổn định.

Core mới → chạy CI → tag `vX.Y.Z` → publish GitHub Packages + release tarball →
app nâng dependency có chủ đích → test → deploy riêng. App đang chạy giữ nguyên
version cho tới khi được nâng cấp và deploy.

Auth/Builder v0.1 là extension contracts; core chưa chứa auth server, visual builder,
workflow engine hay provisioning. Dữ liệu examples là dữ liệu giả. Ba app tích hợp qua canonical compatibility entry points; mỗi app vẫn build và deploy riêng. Xem
[consumer map](docs/consumer-map.md), [integration](docs/integration.md),
[architecture](docs/architecture.md) và [source provenance](docs/source-provenance.md).

## UI Design System là nguồn chuẩn

Bản 0.2.0 đưa nguyên component primitives, tooltip, helper bảng và live CSS từ UI
Design System v243 vào các entry `/ui/canonical/*`, `/ui/tooltip-position`,
`/patterns/property-model`, `/patterns/table-column-model`, `/utils/locale-format`.
Website dùng lại qua compatibility facades, giữ DOM/CSS, language và state hiện có.
Các exports typed `/ui` và `/app` ban đầu tiếp tục là opt-in; chúng không thay thế
tự động những renderer đã có trong app.

`config/ph-standard` chứa public design exports/fonts của UI System. Portable CSS
và live website CSS là hai surface riêng để giữ đúng cascade. `/table-resize.js`
giữ variant chung của Process/Template; `/ui/canonical/table-resize.js` giữ variant
của UI System. Không trộn hai implementation có khác biệt hành vi.

Các app hiện pin tarball Core trong `vendor/` qua npm dependency `file:` và lockfile.
Đây là cùng package release, không phải copy source components vào từng app.
Cách phân phối này giúp các build private trên Sites/Vercel không cần token registry
mới; GitHub Packages và release tarball vẫn được xuất bản cùng version.

Luồng cập nhật: chỉnh và duyệt UI System → promote canonical source/tokens vào
Core → test/release → cập nhật tarball/version của app → test → deploy từng app.
