# PH Core consumer map

PH Core is the shared source and versioned package for PH applications. UI Design System, Process Simulation and the Runtime Template remain separate applications. They consume the same package through explicit entry points and retain their own routes, records, settings transactions, deployment and server authorization.

Package name: `@wecare2020/ph-core`.

## Directory and package boundaries

| Core directory | Package entry point | Responsibility | Consumers |
| --- | --- | --- | --- |
| `ui/` | `/ui` | Small reusable React controls and PH presentation primitives | UI Design System, Runtime Template, React islands |
| `layouts/` | `/layouts`, compatibility alias `/app` | App and settings shells, navigation, reusable page/record surfaces | React applications |
| `patterns/` | `/patterns` | Composed interaction patterns and shared property vocabulary | App authoring and runtime views |
| `data/` | `/data` | Adapter boundaries, portable data behavior and validation | All applications |
| `utils/` | `/utils` | Framework-neutral formatting, search and collection helpers | All applications |
| `types/` | `/types` | Shared contracts for schemas, records, adapters and application configuration | TypeScript applications and typed integration code |
| `auth/` | `/auth` | Authentication adapter contracts and reusable client behavior | All applications, with server verification owned by each app |
| `builders/` | `/builders` | Configuration construction and validation helpers | UI Design System and Process Simulation authoring |
| `config/` | `/config` | Design tokens and shared configuration | All applications |

`package.json` is the authoritative list of shipped exports. A directory or a source candidate in the tables below does not imply that its full source application has been moved into Core.

## Concrete extraction map

Source paths below are relative to their source application. Provenance and verification details are in [source-provenance.md](./source-provenance.md).

| Source application and file | Core destination | Extraction boundary |
| --- | --- | --- |
| UI Library `public/ph-tokens.json` | `config/` | Canonical PH 0.4.0 colors, typography, geometry and treatment metadata |
| UI Library `public/ph-design-system.css` | `ui/`, `config/` | Shared PH styling; keep app selectors out of general primitives |
| UI Library `src/locale-format.mjs` | `utils/` | Date/number/currency formatting; make currency an explicit option rather than assuming every app uses VND |
| UI Library `src/table-column-model.mjs` | `data/`, `utils/` | Pure value filtering, tree projection and column state; make locale explicit where needed |
| UI Library `src/property-model.mjs`; Runtime Template `property-topics.ts` | `patterns/`, `builders/` | General / Design / Behaviour and supported subgroup assignment |
| UI Library `src/ui.jsx` | `ui/` | Button, IconButton, Badge, Alert, Field and CommandBar behavior; remove showcase catalog/context dependencies |
| UI Library `src/Select.jsx`; Runtime Template `Select.tsx` | `ui/` | Accessible viewport-bounded dropdown behavior; application translations and icon choices stay injectable |
| UI Library `src/TooltipLayer.jsx` | `ui/` | Positioned tooltip behavior with lifecycle cleanup |
| UI Library `src/richtext/blocknote-format-options.ts`; Process `ui/process-editor/format-options.mjs` | `builders/` | Safe text-format targets; optional rich editor integration should remain a separate heavy dependency |
| UI Library and Process `public/ph-shell-bridge.js` | `layouts/` | Shared child-shell protocol; retain trusted origin checks and opt-in chrome handling |
| Runtime Template `types.ts` | `types/`, `data/`, `auth/` | Record/schema, DataAdapter, AuthAdapter and StudioAdapter contracts; separate process-specific definitions |
| Runtime Template `runtime.ts` | `data/`, `utils/`, `builders/` | Portable row/schema checks and selection/export helpers; do not inherit template-specific route restrictions or demo seeding |
| Process `public/app-display-model.js` | Future `data/`, `builders/` extraction | Pure navigation/projection candidates require schema translation; the existing UMD module is not equivalent to the Template Definition model |
| Runtime Template `server-sync-merge.ts` | Future server-side `data/` adapter | Reuse non-destructive merge semantics only after separating Node crypto, settings document types and persistence ownership |

## React integration

UI Design System and Runtime Template currently use React 19.2. They can consume `/ui`, `/layouts` and `/patterns` alongside the framework-neutral exports. React is an optional peer for the package as a whole; consumers of React entry points must supply compatible `react` and `react-dom` versions.

Use a built local checkout during adoption, for example `npm run build` in Core then `npm install ../ph-core`, and pin a reviewed package version or released tarball for releases. A private GitHub repository does not by itself publish the package to npm or GitHub Packages.

Start by replacing copied token values and pure helpers. Then replace primitives individually, retaining the application's public props, labels, keyboard behavior, focus return and draft guards. Keep business renderer composition in the consuming application until its schema is represented by a stable Core contract.

## Vanilla Process Simulation integration

Process Simulation combines a vanilla browser shell and worker backend with React islands. Its vanilla code should import only framework-neutral `/config`, `/data`, `/utils`, `/types`, `/auth` contracts and appropriate `/builders` helpers. Its build already uses esbuild and can bundle ESM dependencies. React islands can adopt `/ui` independently without rewriting the main shell.

The current Process record envelope and field types differ from the Template model. Process projection reads `row.values` and uses `Text`, `Number`, `Date`, `Boolean`, `Reference`; Template rows hold values directly and use lowercase field types. Add an explicit mapping adapter and test its round trip before sharing renderers. Retain Process version IDs, revisions, worker persistence and existing authorization at the application boundary.

## Implemented versus staged

This repository is an initial shared package with reusable foundations and integration examples. Its actual source exports and tests define the implemented scope. The inventory above also identifies source candidates for subsequent adoption; it is not a claim of complete source parity.

The following remain staged unless an application separately adopts and verifies them:

- Replacing the existing UI Design System, Process Simulation or Runtime Template production bundles with Core imports.
- Full schema-driven TableView, FormEngine, RecordDrawer and workflow renderer parity across all three applications.
- Moving production connectors, credential handling, JWT verification, session persistence, server settings, audit, backups or records into Core.
- Loading an automatic, unversioned CDN reference to the latest Core source.

Package publication is handled by the `Release Core` workflow on version tags;
its successful run and the GitHub Packages version are the release authority.

Existing applications still own their saved state and deployment. No production records, settings or authentication sessions are copied into this repository.

## Adoption acceptance checks

1. Pin the Core version and keep each app's existing `app.id`, data sources and persistence keys.
2. Verify tokens against the current PH UI reference. Primary actions are outlined white controls, with restrained walnut foreground; form section titles are 16px Roboto 600 and labels use `#565E65`.
3. Compare keyboard navigation, selected state, mobile overflow and focus return for each adopted primitive.
4. Verify create/edit/cancel/reload and preservation of intentional empty arrays, drafts, IDs and revisions at the application level.
5. Run the consumer's existing checks, then deploy that consumer only as a separate, explicitly reviewed adoption change.
